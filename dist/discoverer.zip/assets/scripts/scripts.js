import Menu from "./modules/menu.js";
import Navigation from "./modules/navigation.js";

console.log("Hello from The Discoverer!");

const menu = new Menu();
const navigation = new Navigation();
